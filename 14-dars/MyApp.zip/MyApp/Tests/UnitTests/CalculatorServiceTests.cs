using Xunit;
using MyApp.Services;
public class CalculatorServiceTests
{
    [Fact]
    public void Add_ShouldReturnCorrectSum()
    {
        // servisni olib kelish
        var service = new CalculatorService();
        // servisdan natija olish
        var result = service.Add(2, 3);
        // kutilayotgan natija bilan tenglash
        Assert.NotEqual(0, result);
    }
}
